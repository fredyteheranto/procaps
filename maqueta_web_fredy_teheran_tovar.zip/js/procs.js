$(document).ready(function() {
    $('.carousel').carousel({interval: 7000});
  });